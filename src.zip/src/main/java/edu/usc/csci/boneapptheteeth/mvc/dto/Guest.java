package edu.usc.csci.boneapptheteeth.mvc.dto;

public class Guest extends User {

    private String access = "registered";

    public Guest() {}
}

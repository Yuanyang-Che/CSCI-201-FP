package edu.usc.csci.boneapptheteeth.model;

import org.springframework.data.repository.CrudRepository;

public interface LastRecipeRepository extends CrudRepository<LastRecipe, String> {

}
 